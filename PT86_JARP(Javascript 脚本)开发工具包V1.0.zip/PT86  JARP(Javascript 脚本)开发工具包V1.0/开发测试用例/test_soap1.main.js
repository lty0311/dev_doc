var soap = require('soap');  //导入soap模块
var xml = require('xml');

soap.initialize(true);  //初始化为客户端

var ctx = soap.client_newctx('http://tempuri.org/','GetProvinceAnimalKind');  //新建一个客户端执行环境
//ctx.additem('xs:string', 'arg0', 'hello');  //添加参数
//ctx.additem('xs:string', 'arg1', 'world');  //添加参数
ctx.on('onResponse', function(err, doc){   //注册'onResponse'回调函数，接收数据
    if(err == null){
		console.log('onResponse');
        var root = xml.docGetRootElement(doc);
        var content = xml.nodeGetContent(root);
        console.log(content);
		xml.saveFile('demo.xml', doc);  //将应答数据保存为xml文件
    }else{
		console.log(err);
	}
    ctx.destroy();
});
ctx.invoke('http://zs.zjahv.gov.cn:8900/W_PDA_Interface.asmx', 'http://tempuri.org/GetProvinceAnimalKind');   //调用远程服务