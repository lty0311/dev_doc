var db = require('db');

db.initialize(); //使用数据库之前必须先初始化

var mydbfile = db.open('/datafs/data/test2.db');  //打开数据库文件
try{
	mydbfile.exec('create table Test(id integet primary key, name text not null, price float, data blob)'); //执行sql语句
}catch(err){
	//console.log(err);
}

// 参数化语句机制
mystmt = mydbfile.getstmt('insert into Test(id,name,price,data) values(?,?,?,?)'); //获取参数化语句对象，？占位符表示参数
mystmt.bind(1, 1);  //绑定参数
mystmt.bind(2, 'wuhz');
mystmt.bind(3, 95.5);
mystmt.bind(4, new Buffer('hello world'));
mystmt.step();  //执行语句

mystmt.reset();  //清除参数绑定
mystmt.bind(1, 2);
mystmt.bind(2, 'lizz');
mystmt.bind(3, 88);
mystmt.bind(4, new Buffer('hello world'));
mystmt.step();
mystmt.finalize();  //关闭语句

console.log('## raw data ##');
mystmt = mydbfile.getstmt('select * from Test');
while(mystmt.step()){
	var id = mystmt.column(0);  //读取记录字段
	var name = mystmt.column(1);
	var price = mystmt.column(2);
	var data = mystmt.column(3);
	console.log('id: ' + id + '  name: ' + name + '  price: ' + price + '  data: ' + data);
}
mystmt.finalize();

// 事务机制 回滚
console.log('\n\n');
console.log('## transaction rollback ##');
mydbfile.exec('begin'); //打开事务
mydbfile.exec('delete from Test'); //删除Test表中的所有记录
mydbfile.exec('rollback');  //事务回滚

//验证回滚操作成功，以上的删除操作未生效
mystmt = mydbfile.getstmt('select * from Test');
while(mystmt.step()){
	var id = mystmt.column(0);  //读取记录字段
	var name = mystmt.column(1);
	var price = mystmt.column(2);
	var data = mystmt.column(3);
	console.log('id: ' + id + '  name: ' + name + '  price: ' + price + '  data: ' + data);
}
mystmt.finalize();

// 事务机制 提交
console.log('\n\n');
console.log('## transaction commit ##');
mydbfile.exec('begin');
mydbfile.exec('delete from Test');  //删除Test表中的所有记录
mydbfile.exec('commit');

//验证删除操作已生效
mystmt = mydbfile.getstmt('select * from Test');
while(mystmt.step()){
	var id = mystmt.column(0);  //读取记录字段
	var name = mystmt.column(1);
	var price = mystmt.column(2);
	var data = mystmt.column(3);
	console.log('id: ' + id + '  name: ' + name + '  price: ' + price + '  data: ' + data);
}
console.log('\n');
mystmt.finalize();

mydbfile.close();  //关闭数据库连接
db.release();
