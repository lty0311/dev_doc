var fs = require('fs');
var dirpath = './demodir';
fs.mkdir(dirpath);