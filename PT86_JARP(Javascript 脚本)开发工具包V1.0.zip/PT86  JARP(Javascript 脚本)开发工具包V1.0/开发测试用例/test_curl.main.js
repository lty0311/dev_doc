var curl = require('curl');

curl.initialize();
var req = curl.getreqwrap();

//DownloadFile 测试
req.settype(req.DownloadFile);  //设置请求类型
req.seturl('http://s1.hao123img.com/res/images/search_logo/web.png');  //设置URL
req.on('onDownloadFile', function(err){  //注册对应请求类型的回调函数，以接收数据或处理异常
	console.log(err.toString);
});
req.run();  //执行请求操作

req.destroy();
curl.release();