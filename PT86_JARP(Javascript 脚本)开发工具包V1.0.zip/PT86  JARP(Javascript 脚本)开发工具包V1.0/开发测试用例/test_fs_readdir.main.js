var fs = require('fs');
console.debug = true; //打开调试接口

var dir = fs.opendir('/');  //打开目录
var files = fs.readdir(dir);  //读取目录
console.log(files);  
fs.closedir(dir);  //关闭目录