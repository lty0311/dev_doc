var fs = require('fs');
var statInfo = fs.statSync('demo.txt');
console.log(statInfo);