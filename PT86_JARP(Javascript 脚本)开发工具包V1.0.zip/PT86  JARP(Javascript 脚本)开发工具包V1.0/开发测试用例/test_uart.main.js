var Uart = require('uart').Uart;
var uart = new Uart();
var buf = new Buffer('hello world\n');

uart.open('/dev/ttyGS0');
uart.write(buf);
