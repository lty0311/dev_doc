var fs = require('fs');
fs.open('demo.txt', 'a', function(err,fd){
 if(err){
  throw err;
 }
 console.log('file open');
 
 var buf = new Buffer("hello world\n");
 fs.write(fd, buf, 0, buf.length, function(err, bytesRead){
   if(err){
	throw err;
   }else{
	   console.log('bytesRead: '+bytesRead);
   }
 }); 
 
 fs.close(fd , function(){
  console.log('file close');
 });
});
