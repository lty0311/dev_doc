var fs = require('fs');
fs.open('demo.txt', 'a', function(err,fd){
 if(err){
  throw err;
 }
 console.log('file open');
 
 var buf = new Buffer("hello world\n");
 var bytesRead = fs.writeSync(fd, buf, 0, buf.length, null); 
 console.log(bytesRead);
 
 fs.close(fd , function(){
  console.log('file close');
 });
});
