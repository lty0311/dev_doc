var xml = require('xml');
xml.initialize();

var doc = xml.parseFile('/datafs/data/gjobs.xml');  //解析xml文件
var rootelement = xml.docGetRootElement(doc);  //获取根元素
var content = xml.nodeGetContent(rootelement); //获取根元素的内容
console.log(content);

xml.release();
