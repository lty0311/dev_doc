var fs = require('fs');
var dirpath = './demodir';
fs.rmdir(dirpath);