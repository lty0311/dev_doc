var buf1 = new Buffer('aaaaaa');
var buf2 = new Buffer('bbbbbb');

buf1.copy(buf2, 3, 3, 5);

console.log(buf1.toString());
console.log(buf2.toString());
