var soap = require('soap');  //导入soap模块
var xml = require('xml');
soap.initialize(true);  //初始化为客户端
var ctx = soap.client_newctx('test','method1');  //新建一个客户端执行环境
ctx.additem('xs:string', 'param', 'value');  //添加参数
ctx.on('onResponse', function(err, doc){   //注册'onResponse'回调函数，接收返回数据并处理错误
	if(err == null){
		var content = xml.nodeGetContent(doc);
		console.log(content);
	}
});
ctx.invoke('http://www.test.com/testserver');  //调用远程服务
ctx.destroy();  //销毁执行环境
soap.release();