var http = require('http');  //导入http模块

var responseCheck = '';
var connectionEvent = 0;
var serverCloseEvent = 0;
var requestEvent = 0;
var responseEvent = 0;
var socketEvent = 0;

// Server端代码
// 服务器会返回接收到的客户端信息
// 当收到'close server'信息时关闭服务器
var server = http.createServer(function (req, res) {  //获取http.Server对象 并注册请求监听器

  var body = '';
  var url = req.url;

  req.on('data', function (chunk) {
    body += chunk;
  });

  var endHandler = function () {

    res.writeHead(200, { 'Connection' : 'close',
                         'Content-Length' : body.length
                       });
    res.write(body);
    res.end(function(){
      if(body == 'close server') {
        server.close();
      }
    });
  };

  req.on('end', endHandler);

});

server.on('request', function() {  //注册request事件监听器
  requestEvent++;
});

server.on('connection', function() {  //注册connection事件监听器
  connectionEvent++;
});

server.on('close', function() {  //注册close事件监听器
  serverCloseEvent++;
});

server.listen(3001, 3);  //服务器启动监听3001端口


// client端 代码
// 1. 发送POST请求到服务器并检查应答信息
// 2. 发送GET请求到服务器并检查应答信息
// 3. 发送'close server'信息

// 1. POST 请求
var msg = 'http request test msg';
var options = {  //设置头部选项
  method : 'POST',  //方法
  port : 3001,      //端口号
  headers : {'Content-Length': msg.length}
};


var postResponseHandler = function (res) {  //应答监听器
  var res_body = '';

  assert.equal(200, res.statusCode);
  var endHandler = function(){
    assert.equal(msg, res_body);
    responseCheck += '1';
  };
  res.on('end', endHandler);

  res.on('data', function(chunk){
    res_body += chunk.toString();
	console.log('response: '+res_body);
  });
};

var req = http.request(options, postResponseHandler);  //获取http.ClientRequest对象
req.on('response', function() {  //注册'response'事件监听器
  responseEvent++;
});
req.on('socket', function() {  //注册'socket'事件监听器
  socketEvent++;
});
req.write(msg);  //发送数据
req.end();  //停止发送数据


// 2. GET req
options = {
  method : 'GET',
  port : 3001
};

var getResponseHandler = function (res) {
  var res_body = '';

  assert.equal(200, res.statusCode);

  var endHandler = function(){
    // GET msg, no received body
    assert.equal('', res_body);
    responseCheck += '2';
  };
  res.on('end', endHandler);

  res.on('data', function(chunk){
    res_body += chunk.toString();
  });
};


var getReq = http.request(options, getResponseHandler);
getReq.on('response', function() {
  responseEvent++;
});
getReq.on('socket', function() {
  socketEvent++;
});
getReq.end();



// 3. 关闭服务器请求
var finalMsg = 'close server';  //请求关闭信息
var finalOptions = {  //设置头部选项
  method : 'POST',
  port : 3001,
  headers : {'Content-Length': finalMsg.length}
};

var finalResponseHandler = function (res) {  //应答监听器
  var res_body = '';

  assert.equal(200, res.statusCode);  //判断应答报文的状态码是否为200

  var endHandler = function(){
    assert.equal(finalMsg, res_body);
    responseCheck += '3';
  };
  res.on('end', endHandler);

  res.on('data', function(chunk){
    res_body += chunk.toString();
  });
};

var finalReq = http.request(finalOptions, finalResponseHandler);  //获取http.ClientRequest对象
finalReq.on('response', function() {  //注册'response'事件
  responseEvent++;
});
finalReq.on('socket', function() {  //注册'socket'事件
  socketEvent++;
});
finalReq.write(finalMsg);  //发送数据
finalReq.end();  //停止发送数据
