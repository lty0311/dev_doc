var net = require('net'); //导入net模块

var port = 22701;
var server = net.createServer(); //创建一个TCP服务器
server.listen(port, 5);  //监听端口
server.on('connection', function(socket) { //注册'connection'事件回调
  console.log('client connect');
  socket.on('data', function(data) {  //注册'data'事件回调
	console.log('client data');
  });
  socket.on('close', function() {  //注册'close'事件回调
	console.log('client close');
    server.close();
  });
});

var socket = net.connect(22701);  //创建一个client套接字并连接服务器
socket.write('hello');  //给服务器发送数据
socket.end();  //关闭client套接字
