var gui = require('gui');
var service = require('service'); //获取服务

gui.initialize();
var vibrator = new service.Vibrator();

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){
    var button = gui.getbuttonwrap();
    button.on('onButtonClicked', function(){
        vibrator.vibrator(3000);  //振动3000毫秒
    });
    button.createbutton(dialog, 0, 50, 60, 60, 20, '振动3秒');
    button.setfocus();
    
    var button2 = gui.getbuttonwrap();
    button2.on('onButtonClicked', function(){
        vibrator.vibratoron();  //打开振动（不限时）
    });
    button2.createbutton(dialog, 0, 20, 90, 60, 20, '打开振动');
    
    var button3 = gui.getbuttonwrap();
    button3.on('onButtonClicked', function(){
        vibrator.vibratoroff();  //关闭振动
    });
    button3.createbutton(dialog, 0, 90, 90, 60, 20, '关闭振动');
});
dialog.on('onKeydown', function(key){
    if(key == 1){  //ESC
        dialog.destroydialogbox();
        gui.release();
		vibrator.vibratoroff();
    }
});
dialog.createdialogbox(0, 'vibratorDialog');
