var gui = require("gui");

gui.initialize();

var ESC = 1;
var OK = 59;

var win = gui.getwinwrap();
win.on('onPaint', function(hdc){
	gui.circle(hdc, 80, 80, 40);
	gui.drawtext(hdc, 0, 0, 40, 20, 'drawtext', gui.drawtext.DT_CENTER);
	gui.textout(hdc, 0, 20, 'textout');
	gui.rectangle(hdc, 2, 40, 40, 60);
});
win.on('onKeydown', function(key){
	if(key == OK){
		var dialog = gui.getdialogwrap();
		dialog.on('onInitdialog', function(){
			var button = gui.getbuttonwrap();
			button.createbutton(dialog, 0, 20, 60, 60, 20, 'Hello World');
			button.setfocus();
		});
		dialog.on('onKeydown', function(key){
			if(key == ESC){
				dialog.destroydialogbox();
			}
		});
		dialog.createdialogbox(0, 'Dialog', win);
	}else if(key == ESC){
		win.destroywindow();
		gui.release();
	}
});
win.createwindow(0, 'MainWin');
