var gui = require('gui');
var Uart = require('uart').Uart;  //导入uart模块
var uart = new Uart();

gui.initialize();
console.debug = true;

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){
	var sledit = gui.getsleditwrap();
	sledit.createsledit(dialog, 0, 30, 50, 100, 20);
	sledit.setfocus();
	uart.open('/dev/ttyGS0');
	uart.on('onData', function(err, isEnd, data){
		if(err == null){ //判断是否出错
			if(isEnd == false){  //判断是否无数据可以接收
				sledit.setsledit(data.toString()); 
			}
		}
	});
	uart.asyncread();
});
dialog.on('onKeydown', function(key){
	if(key == 1){//按ESC键
		uart.write(new Buffer('bye!\n'));
		uart.destroy();
    	gui.release();
	}
});
dialog.createdialogbox(0, 'uartDialog');