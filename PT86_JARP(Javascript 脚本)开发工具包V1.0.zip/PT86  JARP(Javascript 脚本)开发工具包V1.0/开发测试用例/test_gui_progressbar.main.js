var gui = require('gui');

gui.initialize();

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){

	var progressbar = gui.getprogressbarwrap();
	progressbar.createprogressbar(dialog, 0, 20, 50, 80, 20);
	progressbar.setrange(0, 100);
	progressbar.setstep(2);
	progressbar.setpos(0);

	var button = gui.getbuttonwrap();
	button.on('onButtonClicked', function(){
		dialog.destroydialogbox();
		gui.release();
		clearInterval(timer);
	});
	button.createbutton(dialog, 0, 50, 100, 50, 15, '退出');
	button.setfocus();

	var button2 = gui.getbuttonwrap();
	button2.on('onButtonClicked', function(){
		progressbar.deltapos(-100);
	});
	button2.createbutton(dialog, 0, 50, 80, 50, 15, '回退');

	var timer = setInterval(function(){
		progressbar.stepit();
	}, 200);

});
dialog.createdialogbox(0, 'Dialog');

