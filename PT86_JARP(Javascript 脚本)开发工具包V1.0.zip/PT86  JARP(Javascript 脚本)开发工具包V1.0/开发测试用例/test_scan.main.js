var gui = require('gui');
var Scan = require('scan');  //导入scan模块

gui.initialize();
var scanServ = new Scan();  //scan服务实例化

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){
	var sledit = gui.getsleditwrap();
	sledit.createsledit(dialog, 0, 30, 50, 100, 20);
	sledit.setfocus();

	scanServ.on('onBarcode', function(err, isEnd, data){  //scan服务注册'onBarcode'事件回调，接收条码数据
		if(err == null){ //判断是否出错
			if(isEnd == false){  //判断是否接收完数据
				sledit.setsledit(data.slice(4).toString()); 
			}
		}
	});
	scanServ.start();  //扫码服务开启
});
dialog.on('onKeydown', function(key){
	if(key == 1){//按ESC键
		scanServ.end();  //关闭扫码服务
		gui.release();
	}
});
dialog.createdialogbox(0, 'scanDialog');