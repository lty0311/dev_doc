var gui = require('gui');
var service = require('service'); //获取service模块

gui.initialize();
var led = new service.LED();
led.initialize();

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){
    var button = gui.getbuttonwrap();
    button.on('onButtonClicked', function(){
		led.setgreen1off();
		led.setred2off();
		led.setgreen2off();
		led.setred1on();  // 亮红灯1
    });
    button.createbutton(dialog, 0, 20, 60, 60, 20, '亮红灯1');
    button.setfocus();
    
    var button2 = gui.getbuttonwrap();
    button2.on('onButtonClicked', function(){
		led.setred1off();
		led.setred2off();
		led.setgreen2off();
		led.setgreen1on();  // 亮绿灯1
    });
    button2.createbutton(dialog, 0, 20, 90, 60, 20, '亮绿灯1');
    
    var button3 = gui.getbuttonwrap();
    button3.on('onButtonClicked', function(){
		led.setred1off();
		led.setgreen1off();
		led.setgreen2off();
        led.setred2on();  // 亮红灯2
    });
    button3.createbutton(dialog, 0, 90, 60, 60, 20, '亮红灯2');
	
	var button4 = gui.getbuttonwrap();
    button4.on('onButtonClicked', function(){
		led.setred1off();
		led.setgreen1off();
		led.setred2off();
        led.setgreen2on();  // 亮绿灯2
    });
    button4.createbutton(dialog, 0, 90, 90, 60, 20, '亮绿灯2');
});
dialog.on('onKeydown', function(key){
    if(key == 1){  //ESC
        dialog.destroydialogbox();
        gui.release();
		led.release();
    }
});
dialog.createdialogbox(0, 'LED_test Dialog');
