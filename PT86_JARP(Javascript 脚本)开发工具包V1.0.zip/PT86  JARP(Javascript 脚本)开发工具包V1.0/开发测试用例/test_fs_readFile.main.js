var fs = require('fs');

fs.readFile('demo.txt', function(err, data){
	if(err){
		console.log('read err');
	}else{
		console.log('data: ' + data.toString());
	}
})