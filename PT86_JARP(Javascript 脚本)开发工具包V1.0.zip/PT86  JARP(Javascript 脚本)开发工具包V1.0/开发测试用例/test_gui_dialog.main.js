var gui = require("gui"); //获取内置gui模块接口

gui.initialize();  //gui初始化

var ESC = 1; //ESC键码
var OK = 59; //OK键码

var dialog = gui.getdialogwrap();  //获取对话框封装对象

dialog.on('onInitdialog', function(){  //注册onInitdialog事件回调

	var static = gui.getstaticwrap();
	static.createstatic(dialog, 0, 30, 60, 100, 20, static.SS_CENTER, '');
	
	var button = gui.getbuttonwrap();
	button.on('onButtonClicked', function(){
		static.setstatic('hello world');
	});
	button.createbutton(dialog, 0, 50, 100, 50, 15, 'hello');
	button.setfocus();
	
});

dialog.on('onKeydown', function(key){  //注册onKeydown事件回调

	if(key == OK){
		
	}else if(key == ESC){
		dialog.destroydialogbox();  //销毁对话框
		gui.release();  //退出gui事件循环
	}
	
});

dialog.createdialogbox(0, 'dialog');  //创建对话框
