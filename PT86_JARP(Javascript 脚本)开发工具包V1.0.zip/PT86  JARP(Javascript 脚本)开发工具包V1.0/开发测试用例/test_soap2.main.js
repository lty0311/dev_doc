var soap = require('soap');  //导入soap模块
var xml = require('xml');

soap.initialize(true);  //初始化为客户端

var ctx = soap.client_newctx('http://ws.syzs.newland.com/','getUserInfo');  //新建一个客户端执行环境
ctx.additem('xs:string', 'arg0', '5194127');  //添加参数
ctx.additem('xs:string', 'arg1', '888888');
ctx.on('onResponse', function(err, doc){   //注册'onResponse'回调函数，接收返回数
    if(err == null){
		console.log('onResponse');
        var root = xml.docGetRootElement(doc);
        var content = xml.nodeGetContent(root);
        console.log(content);
		xml.saveFile('demo.xml', doc);  //将应答数据保存为xml文件
    }
    ctx.destroy();
});
ctx.invoke('http://222.35.47.104:8081/SyZs/SyzsWs2Port?wsdl', 'http://ws.syzs.newland.com/getUserInfo');   //调用远程服务

