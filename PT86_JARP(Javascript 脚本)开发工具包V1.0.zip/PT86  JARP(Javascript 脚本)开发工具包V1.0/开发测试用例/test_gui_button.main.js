var gui = require("gui"); //获取内置gui模块接口

gui.initialize();  //gui初始化

var ESC = 1; //ESC键码
var OK = 59; //OK键

var dialog = gui.getdialogwrap();

dialog.on('onInitdialog', function(){

	var button = gui.getbuttonwrap(); //获取button封装对象
	button.on('onButtonClicked', function(){  //注册onButtonClicked事件回调
		gui.messagebox('onButtonClicked', 'title');
	});
	button.createbutton(dialog, 0, 50, 50, 60, 20, 'button');  //创建按钮
	button.setfocus();  //获取焦点
	
});

dialog.on('onKeydown', function(key){

	if(key == ESC){
		dialog.destroydialogbox();  //销毁对话框
		gui.release();  //退出gui事件循环
	}
	
});

dialog.createdialogbox(0, 'dialog');
