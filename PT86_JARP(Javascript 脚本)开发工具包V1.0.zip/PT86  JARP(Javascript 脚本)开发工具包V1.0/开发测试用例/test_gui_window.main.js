var gui = require("gui");  //获取内置gui模块接口

gui.initialize();  //gui初始化

var ESC = 1;  //ESC键码
var OK = 59;  //OK键码

var win = gui.getwinwrap();  //获取窗口封装对象

win.on('onPaint', function(hdc){  //注册onPaint事件回调

	gui.circle(hdc, 100, 80, 40);  //画圆
	gui.drawtext(hdc, 0, 0, 60, 20, 'drawtext', gui.drawtext.DT_CENTER); //显示文本（可设置显示样式）
	gui.textout(hdc, 0, 20, 'textout');  //显示文本
	gui.rectangle(hdc, 2, 40, 40, 60);  //画矩形
	gui.moveto(hdc, 2, 40);   //画线段
	gui.lineto(hdc, 40, 60);
	
});

win.on('onKeydown', function(key){  //注册onKeydown事件回调
	if(key == OK){
		
	}else if(key == ESC){
		win.destroywindow(); //销毁窗口
		gui.release();  //退出gui事件循环
	}
});

win.createwindow(0, 'Window');  //创建窗口