var gui = require("gui");

gui.initialize();  //gui初始化

var ESC = 1; //ESC键码
var OK = 59; //OK键

var dialog = gui.getdialogwrap();

dialog.on('onInitdialog', function(){

	var sledit = gui.getsleditwrap(); //获取单行编辑框封装对象
	sledit.on('onEditChange', function(text){  //注册onEditChange事件回调
		console.log(text);
	});
	sledit.createsledit(dialog, 0, 30, 50, 100, 20);  //创建单行编辑框
	sledit.setsledit('sledit');  //设置单行编辑框的文本内容
	sledit.setfocus();  //获取焦点
	
});

dialog.on('onKeydown', function(key){

	if(key == ESC){
		dialog.destroydialogbox();
		gui.release();  //退出gui事件循环
	}
	
});

dialog.createdialogbox(0, 'dialog');
