
var fs = require('fs');
var assert = require('assert');

var filePath = "demo.txt";

console.log(fs.readFileSync(filePath));
