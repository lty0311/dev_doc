var crypto = require('crypto');
var fs = require('fs');

crypto.initialize();

//cipher 测试
console.log('## cipher ##');

var cipher = crypto.getcipher(true);  //获取cipher对象
var key = new Buffer('abc123789');  //密钥
var plaintext = fs.readFileSync('plaintext.txt');
console.log('plaintext: '+plaintext);

cipher.init('aes-128-ecb', key);  //初始化，设置算法、密钥
cipher.update(plaintext);
var ciphertext = cipher.final();  //输出密文
console.log('ciphertext: '+ciphertext);


//decipher 测试
console.log('## decipher ##');

console.log('ciphertext: '+ciphertext);
var decipher = crypto.getcipher(false);
decipher.init('aes-128-ecb', key);
decipher.update(ciphertext);
var plaintext2 = decipher.final();
console.log('plaintext: '+plaintext2);


//hash 测试
console.log('## hash ##');
var myhash = crypto.gethash();  //获取哈希对象
myhash.init('md5');  //设置哈希算法
var plaintext = fs.readFileSync('plaintext.txt');
console.log('plaintext: '+plaintext);
myhash.update(plaintext);  //输入源数据
var digest = myhash.digest();  //计算哈希值
console.log('md5: '+digest);

//hmac 测试
console.log('## hmac ##');
var myhmac = crypto.gethmac();  //获取hmac对象
myhmac.init('md5', key);  //初始化设置，选择哈希算法和密钥
var plaintext = fs.readFileSync('plaintext.txt');
myhmac.update(datain);
var hmac = myhmac.digest();  //计算消息认证码
console.log('hmac: '+hmac);


//sign 测试
console.log('## sign ##');
var mysign = crypto.getsign();  //获取签名对象
mysign.init('md5'); //初始化，设置哈希算法

var plaintext = fs.readFileSync('plaintext.txt');
console.log('plaintext: '+plaintext);
mysign.update(plaintext); //输入源数据
var privatekey = fs.readFileSync('privatekey');
var sign = mysign.sign(privatekey); //计算签名
console.log('sign: '+sign);


//verify 测试
console.log('## verify ##');
var myverify = crypto.getverify();  //获取验证对象
myverify.init('md5'); //初始化，设置哈希算法

var plaintext = fs.readFileSync('plaintext.txt');
var pubkey = fs.readFileSync('publickey');

myverify.update(plaintext); //输入源数据
var verify = myverify.verify(pubkey, sign); //验证
console.log('verify: '+verify);

//publicEncrypt 测试
var plaintext = fs.readFileSync('plaintext.txt');
var pubkey = fs.readFileSync('publickey');
var pubEnc = crypto.publicEncrypt(pubkey, plaintext, crypto.RSA_NO_PADDING);
console.log('pubkey Encrypt: '+pubEnc);


//privateDecrypt 测试
var privatekey = fs.readFileSync('privatekey');
var file = crypto.privateDecrypt(privatekey, pubEnc, crypto.RSA_NO_PADDING);
console.log('privateDecrypt: '+file);

//privateEncrypt 测试
var plaintext = fs.readFileSync('plaintext.txt');
var privatekey = fs.readFileSync('privatekey');
var priEnc = crypto.privateEncrypt(privatekey, plaintext, crypto.RSA_NO_PADDING);
console.log('privateEncrypt: '+priEnc);


//publicDecrypt 测试
var pubkey = fs.readFileSync('publickey');
var file = crypto.publicDecrypt(pubkey, priEnc, crypto.RSA_NO_PADDING);
console.log('publicDecrypt: '+file);

crypto.release();  //释放cyrpto对象
