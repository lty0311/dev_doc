var fs = require('fs');
console.debug = true;

var buf = new Buffer(100);
var fd = fs.openSync('demo.txt', 'r');
fs.readline(fd, buf);
fs.closeSync(fd);
console.log(buf);