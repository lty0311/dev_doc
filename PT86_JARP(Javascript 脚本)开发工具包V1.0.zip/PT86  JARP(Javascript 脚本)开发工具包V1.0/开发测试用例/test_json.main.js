console.debug = true; 
var o = {x:1, y:{z:[false,null,""]}};
s = JSON.stringify(o);  //生成json字符串
console.log(s);
p = JSON.parse(s);  //解析json字符串
console.log(p);
