var gui = require('gui');
var service = require('service'); //获取服务

gui.initialize();
var sn = new service.SN();

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){
	
	var static = gui.getstaticwrap();
	static.createstatic(dialog, 0, 0, 30, 158, 20, static.SS_CENTER, '');
	
    var button = gui.getbuttonwrap();
    button.on('onButtonClicked', function(){
		var snStr = sn.getsn();  //读取sn号
		static.setstatic(snStr);
    });
    button.createbutton(dialog, 0, 50, 60, 60, 20, '获取SN号');
    button.setfocus();
});
dialog.on('onKeydown', function(key){
    if(key == 1){  //ESC
        dialog.destroydialogbox();
        gui.release();
    }
});
dialog.createdialogbox(0, 'GetSN Dialog');