var gui = require("gui");

gui.initialize();  //gui初始化

var ESC = 1; //ESC键码
var OK = 59; //OK键

var dialog = gui.getdialogwrap();

dialog.on('onInitdialog', function(){

	var mledit = gui.getmleditwrap(); //获取多行编辑框封装对象
	mledit.on('onEditChange', function(text){  //注册onEditChange事件回调
		console.log(text);
	});
	mledit.createmledit(dialog, 0, 30, 50, 100, 40);  //创建多行编辑框
	mledit.setmledit('mledit');  //设置多行编辑框的文本内容
	mledit.setfocus();  //获取焦点
	
});

dialog.on('onKeydown', function(key){

	if(key == ESC){
		dialog.destroydialogbox();
		gui.release();  //退出gui事件循环
	}
	
});

dialog.createdialogbox(0, 'dialog');
