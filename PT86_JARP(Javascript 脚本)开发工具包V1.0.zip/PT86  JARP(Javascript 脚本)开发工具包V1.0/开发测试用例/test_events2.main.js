var EventEmitter = require('events').EventEmitter;  //导入events模块
var emitter = new EventEmitter();  //实例化EventEmitter

function listener1(){
	console.log('event1 listener1');
}

function listener2(){
	console.log('event1 listener2');
}

emitter.on('event1', listener1);  //注册事件监听器
emitter.addListener('event1', listener2);  //添加事件监听器
emitter.emit('event1');  //发送事件

emitter.removeListener('event1', listener1);  //删除事件监听器
emitter.emit('event1');
