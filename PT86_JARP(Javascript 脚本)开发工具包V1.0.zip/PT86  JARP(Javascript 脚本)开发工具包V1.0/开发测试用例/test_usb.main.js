var gui = require('gui');
var service = require('service'); //获取service模块

gui.initialize();

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){
	
	var static = gui.getstaticwrap();
	static.createstatic(dialog, 0, 0, 30, 158, 40, static.SS_CENTER, '');
	
    var button = gui.getbuttonwrap();
    button.on('onButtonClicked', function(){
		var status = ( new service.USB() ).getstatus();  //读取USB状态
		static.setstatic('状态：' + status);
    });
    button.createbutton(dialog, 0, 50, 90, 60, 20, '获取USB状态');
    button.setfocus();
});
dialog.on('onKeydown', function(key){
    if(key == 1){  //ESC
        dialog.destroydialogbox();
        gui.release();
    }
});
dialog.createdialogbox(0, 'GetUSBInfo Dialog');