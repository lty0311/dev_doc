var gui = require("gui");

gui.initialize();  //gui初始化

var ESC = 1; //ESC键码
var OK = 59; //OK键码

var dialog = gui.getdialogwrap();

dialog.on('onInitdialog', function(){

	var combobox = gui.getcomboboxwrap(); //获取组合框封装对象
	combobox.on('onEditChange', function(text){
		gui.messagebox(text, '组合框内容');
	});
	combobox.createcombobox(dialog, 0, 30, 10, 80, 20);  //创建组合框
	combobox.addlistbox('item1');  //添加选项
	combobox.addlistbox('item2');
	combobox.addlistbox('item3');
	combobox.addlistbox('item4');
	combobox.addlistbox('item5');
	combobox.addlistbox('item6');
	combobox.addlistbox('item7');
	combobox.addlistbox('item8');
	combobox.setfocus(); //获取焦点
	
});

dialog.on('onKeydown', function(key){

	if(key == ESC){
		dialog.destroydialogbox();  //销毁对话框
		gui.release();  //退出gui事件循环
	}
	
});

dialog.createdialogbox(0, 'dialog');
