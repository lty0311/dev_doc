var net = require('net');  //导入net模块
var port = 22702;

var server = net.createServer({  //创建TCP server
  allowHalfOpen: true
});

server.listen(port, 5);  //server开始监听

server.on('connection', function(socket) {  //server注册'connection'事件监听器
  var msg = '';
  socket.on('data', function(data) { //server socket注册'data'事件监听器
    msg += data;
  });
  socket.on('end', function() {  //server socket注册'end'事件监听器
    socket.end(msg);
    server.close();
  });
});

var socket = new net.Socket();  //新建client socket
var client_msg = '';

socket.connect(port, '127.0.0.1');  //client socket连接server
socket.write('hello world');  //client socket发送数据
socket.end();  //关闭client socket

socket.on('data', function(data) {  //client socket注册'data'事件监听器
  client_msg += data;
});

socket.on('end', function() {  //client socket注册'end'事件监听器
  console.log(client_msg);
});
