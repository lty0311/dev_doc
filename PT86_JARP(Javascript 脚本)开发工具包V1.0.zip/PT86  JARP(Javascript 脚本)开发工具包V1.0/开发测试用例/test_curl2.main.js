var curl = require('curl');  //调用curl模块

curl.initialize();  //初始化

var req = curl.getreqwrap();  //获取请求对象
req.settype(req.Get);  //设置请求类型
req.seturl('http://www.baidu.com/');  //设置资源url
req.on('onGet', function(err, text){   //注册事件回调函数
	console.log(text);
	console.log(err);
});
req.run();  //执行请求
