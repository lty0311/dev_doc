var gui = require("gui"); //获取内置gui模块接口

gui.initialize();  //gui初始化

var ESC = 1; //ESC键码
var OK = 59; //OK键码

var dialog = gui.getdialogwrap();  //获取对话框封装对象

dialog.on('onInitdialog', function(){  //注册onInitdialog事件回调

	var listbox = gui.getlistboxwrap(); //获取列表框封装对象
	listbox.on('onListboxEnter', function(cur_sel){
		gui.messagebox('选中第'+(cur_sel+1)+'项', '提示');
	});
	listbox.createlistbox(dialog, 0, 30, 30, 80, 60);  //创建列表框
	listbox.addlistbox('item1');  //添加列表项
	listbox.addlistbox('item2');
	listbox.addlistbox('item3');
	listbox.addlistbox('item4');
	listbox.addlistbox('item5');
	listbox.addlistbox('item6');
	listbox.addlistbox('item7');
	listbox.addlistbox('item8');
	listbox.setfocus(); //获取焦点
	
});

dialog.on('onKeydown', function(key){  //注册onKeydown事件回调

	if(key == ESC){
		dialog.destroydialogbox();  //销毁对话框
		gui.release();  //退出gui事件循环
	}
	
});

dialog.createdialogbox(0, 'dialog');  //创建对话框
