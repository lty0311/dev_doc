var gui = require('gui');
var service = require('service'); //获取服务

gui.initialize();
var buzzer = new service.Buzzer();

var dialog = gui.getdialogwrap();
dialog.on('onInitdialog', function(){
    var button = gui.getbuttonwrap();
    button.on('onButtonClicked', function(){
        buzzer.buzz(3000, 1000);  //蜂鸣3000毫秒，声音频率1000Hz
    });
    button.createbutton(dialog, 0, 50, 60, 60, 20, '蜂鸣3秒');
    button.setfocus();
    
    var button2 = gui.getbuttonwrap();
    button2.on('onButtonClicked', function(){
        buzzer.buzzon(2000);  //打开蜂鸣（不限时），声音频率2000Hz
    });
    button2.createbutton(dialog, 0, 20, 90, 60, 20, '打开蜂鸣');
    
    var button3 = gui.getbuttonwrap();
    button3.on('onButtonClicked', function(){
        buzzer.buzzoff();  //关闭蜂鸣
    });
    button3.createbutton(dialog, 0, 90, 90, 60, 20, '关闭蜂鸣');
});
dialog.on('onKeydown', function(key){
    if(key == 1){  //ESC
        dialog.destroydialogbox();
        gui.release();
		buzzer.buzzoff();
    }
});
dialog.createdialogbox(0, 'BuzzerDialog');
